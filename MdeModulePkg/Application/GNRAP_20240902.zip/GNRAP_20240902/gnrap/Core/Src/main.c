/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define UART_BUFFER_SIZE 			8
#define UART4_BUFFER_SIZE			21

#define BOARDID_DAT_NUMBER			4
#define SERIALID_DAT_NUMBER			4
#define IPINFO_DAT_NUMBER			3
#define BOOTVL_DAT_NUMBER			5

#define EEPROM_DIMM_COUNT_INDEX		0	//DIMM1 0, DIMM2 4 ....
#define EEPROM_DIMM_COUNT_SIZE		MAX_DIMM_NUMBER * sizeof(uint32_t)
#define EEPROM_BOARD_ID_INDEX		EEPROM_DIMM_COUNT_INDEX + EEPROM_DIMM_COUNT_SIZE
#define EERPOM_BOARD_ID_SIZE	    BOARDID_DAT_NUMBER * sizeof(uint32_t)
#define EEPROM_SERIAL_INDEX			EEPROM_BOARD_ID_INDEX + EERPOM_BOARD_ID_SIZE
#define EEPROM_SERIAL_SIZE			SERIALID_DAT_NUMBER * sizeof(uint32_t)
#define EEPROM_IPINFO_INDEX			EEPROM_SERIAL_INDEX + EEPROM_SERIAL_SIZE
#define EEPROM_IPINFO_SIZE			IPINFO_DAT_NUMBER * sizeof(uint32_t)
#define EEPROM_BOOTVL_INDEX			EEPROM_IPINFO_INDEX + EEPROM_IPINFO_SIZE
#define EEPROM_BOOTVL_SIZE			BOOTVL_DAT_NUMBER * sizeof(uint16_t)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart4;

/* USER CODE BEGIN PV */
static uint8_t Uart1Buffer[UART_BUFFER_SIZE];
static uint8_t Uart3Buffer[UART_BUFFER_SIZE];
static uint8_t Uart4Buffer[UART4_BUFFER_SIZE];
static uint8_t bBackMcuReady = 0;

//static uint8_t MMCURV[3] = {0, 0, 1};					// Release Main MCU Version RV : 3bytes
static uint8_t BMCURV[3] = {0, 0, 0};					// Release Back MCU Version RV : 3bytes

static uint8_t DimmStatus = 0;
static uint8_t DimmCountAct[MAX_DIMM_NUMBER];
static uint32_t DimmCountDat[MAX_DIMM_NUMBER];

static uint16_t CpuFan1Cnt = 0;
static uint16_t CpuFan2Cnt = 0;
static uint16_t SysFan1Cnt = 0;
static uint16_t SysFan2Cnt = 0;

static uint16_t FanTach1 = 0;
static uint16_t FanTach2 = 0;
static uint16_t FanTach3 = 0;
static uint16_t FanTach4 = 0;

/*
 *  BIT0 : EEPROM_LAddr
 *  BIT1 : EEPROM_HAddr
 *  BIT2 : RAA_CD_Addr
 *  BIT3 : RAA_EF_Addr
 *  BIT4 : RAA_IJ_Addr
 *  BIT5 : RAA_KL_Addr
 *  BIT6 : ZL9006MIRZ_Addr
 *  BIT7 : MAX6958_Addr
 *  BIT8 : ADC121_CD_Addr
 *  BIT9 : ADC121_EF_Addr
 *  BIT10: ADC121_IJ_Addr
 *  BIT11: ADC121_KL_Addr
 *  BIT12: ADC121_MT_Addr
 */
static uint16_t i2cDeviceStatus = 0;
static uint8_t SetBootVolDone = 0;
static uint8_t I2cDimmVolDone = 0;
static uint8_t Count = 1;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART4_UART_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART1 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void strOut2(uint8_t* pStr, uint16_t s)
{
	HAL_UART_Transmit(&huart2, pStr, s, 0xFFFF);
}

void smemcpy(uint8_t* des, uint8_t* src, uint8_t sz)
{
	uint8_t Index;
	if(sz==0) return;

	for(Index=0 ; Index < sz ; Index++){
		*(des+Index) = *(src+(sz-1-Index));
	}
}

uint16_t swapbytes(uint16_t num) {
    return (num << 8) | (num >> 8);
}

void swap_bytes(void* data, size_t size) {

    uint8_t* bytes = (uint8_t*)data;
    for (size_t i = 0; i < size / 2; ++i) {
        uint8_t temp = bytes[i];
        bytes[i] = bytes[size - 1 - i];
        bytes[size - 1 - i] = temp;
    }
}

void Uart1Transimt()
{
	HAL_UART_Transmit(&huart1, (uint8_t*)&Uart1Buffer, UART_BUFFER_SIZE, HAL_MAX_DELAY);
}

void Uart3Transimt()
{
	if(bBackMcuReady) {
		HAL_UART_Transmit(&huart3, (uint8_t*)&Uart3Buffer, UART_BUFFER_SIZE, HAL_MAX_DELAY);
	}
}

void Uart4Transimt(uint8_t* pDat, uint16_t size)
{
	HAL_UART_Transmit(&huart4, pDat, size, 0xFFFF);
}

void MAX6958_WriteReg(uint8_t reg, uint8_t data)
{
    uint8_t buf[2] = {reg, data};
    printf("MAX6958 WriteReg reg %x data %x\n", reg, data);
    if(HAL_I2C_Master_Transmit(&hi2c2, MAX6958_Addr << 1, buf, 2, HAL_MAX_DELAY) == HAL_OK){
    	printf("status HAL_OK\n");
    } else {
    	printf("status HAL_ERROR\n");
    }
}

void MAX6958AAEE_Init()
{
    MAX6958_WriteReg(0x04, 0x00); // No decode
    MAX6958_WriteReg(0x09, 0x01); // Enable display
    MAX6958_WriteReg(0x0A, 0x0F); // Set brightness to maximum
}

void MAX6958_DisplayDigit(uint8_t digit, uint8_t value)
{
    MAX6958_WriteReg(digit, value);
}


HAL_StatusTypeDef SetMemAuxPwr(uint8_t *pData)
{
    return HAL_I2C_Mem_Write(
    		&hi2c1,
    		ZL9006MIRZ_Addr << 1,
			0x21,	//VOUT_COMMAND (21h)
			I2C_MEMADD_SIZE_8BIT,
			pData,
			2,
			HAL_MAX_DELAY);
}

void GetMemAuxPwr()
{

	uint16_t MT_RtVLT;
	if(HAL_I2C_Mem_Read(
			&hi2c1, ((ZL9006MIRZ_Addr << 1) | 0x01),
			0x8B,
			I2C_MEMADD_SIZE_8BIT,
			(uint8_t*)&MT_RtVLT, 2,
			HAL_MAX_DELAY
	  	  	) == HAL_OK) {

		printf("GetMemAuxPwr %x\n", MT_RtVLT);
		swapbytes(MT_RtVLT);
		printf("GetMemAuxPwr %d\n", MT_RtVLT);
	}
}

void SetInputVolLimit(uint8_t Addr)
{
	uint8_t buf[3] = {0x4B, 0x00, 0x30};	//input limit max 12288mV

	if(HAL_I2C_Master_Transmit(
			&hi2c1,
			Addr << 1,
			buf,
			3,
			HAL_MAX_DELAY
			) == HAL_OK) {

		printf("SetInputVolLimit 1 \n");
	}
}

void SetDIMMCurrentLimit(uint8_t Addr)
{

	//uint8_t SysLimit[3] = {0x14, 0x00, 0x12};	//9216mA
	uint8_t SysLimit[3] = {0x14, 0x00, 0x10};	//8000mA
	uint8_t FwrLimit[3] = {0x3F, 0x00, 0x10}; 	//8192mA

	if(HAL_I2C_Master_Transmit(
			&hi2c1,
			Addr << 1,
			SysLimit,
			3,
			HAL_MAX_DELAY
			) == HAL_OK) {
		printf("SetDIMMCurrentLimit 1 \n");
	}

	if(HAL_I2C_Master_Transmit(
			&hi2c1,
			Addr << 1,
			FwrLimit,
			3,
			HAL_MAX_DELAY
			) == HAL_OK) {
		printf("SetDIMMCurrentLimit 2 \n");
	}
}

HAL_StatusTypeDef SetDimmVoltage(uint8_t Addr, uint16_t voltage)
{
	uint8_t buf[3];

	voltage /= 12; voltage <<= 3;	//RAA489800 data format
	buf[0] = 0x15;
	buf[1] = voltage & 0xFF;		//Low Byte
	buf[2] = (voltage >> 8) & 0xFF; //High Byte

	return HAL_I2C_Master_Transmit(
			&hi2c1,
			Addr << 1,
			buf,
			3,
			HAL_MAX_DELAY);
}

HAL_StatusTypeDef ReadCurVoltage(uint8_t Addr, uint16_t* p)
{
	HAL_StatusTypeDef Status = HAL_ERROR;

	uint8_t rxData[2];
#if 0
	uint8_t txData[1];

	txData[0] = 0x02;
	//HAL_I2C_Master_Transmit(&hi2c2, Addr << 1, txData, 1, HAL_MAX_DELAY);
	//HAL_Delay(50);
	Status = HAL_I2C_Master_Receive(&hi2c2, (Addr << 1)|1, rxData, 2, HAL_MAX_DELAY);
	p[0] = rxData[0];
	p[1] = rxData[1];
#else
	Status = HAL_I2C_Mem_Read(
			&hi2c2,
			Addr << 1,
			0x00,
			I2C_MEMADD_SIZE_8BIT,
			rxData,
			2,
			HAL_MAX_DELAY);
#endif
	printf("Read Cur Addr %x\r", Addr);

    *p = ((rxData[0] << 8) | rxData[1]) >> 4;;

    printf("Read Cur voltage %d\r", *p);
    *p*=8; //6mV or 8mV
    *p/=10;

    printf("Read Cur voltage %d\r", *p);

	return Status;
}

HAL_StatusTypeDef ReadEEpromDat(uint8_t *pDat, uint8_t Index, uint16_t size)
{
	 if(HAL_I2C_Mem_Read(
			 &hi2c1,
			 (EEPROM_LAddr << 1) | 1,
			 Index,
			 I2C_MEMADD_SIZE_8BIT,
			 pDat,
			 size, 1000) != HAL_OK){

		  return HAL_ERROR;
	 }
	 return HAL_OK;
}


HAL_StatusTypeDef WriteEEpromDat(uint8_t *pDat, uint8_t Index, uint16_t size)
{
	if(HAL_I2C_Mem_Write(
			&hi2c1,
		 (EEPROM_LAddr << 1),
		 Index,
		 I2C_MEMADD_SIZE_8BIT,
		 pDat,
		 size, 1000) != HAL_OK){

	 	 return HAL_ERROR;
	}

	return HAL_OK;
}

void SetBootVoltage(uint8_t Addr, uint8_t index)
{

	uint16_t value;
	uint16_t voltage;

	if(ReadEEpromDat(
			(uint8_t*)&value,
			EEPROM_BOOTVL_INDEX+(index*2),
			2
			) == HAL_OK) {
			voltage = swapbytes(value);
			if(voltage > 15000 || voltage < 11000) voltage = 12000;
	} else {
		voltage = 12000;
	}
	SetDimmVoltage(Addr, voltage);
}

void ConfigBootVoltage()
{
	uint8_t i;
	uint8_t hI2C1[] = {RAA_CD_Addr, RAA_EF_Addr, RAA_IJ_Addr, RAA_KL_Addr};
#if 0	//TBD
	uint16_t Voltage;
#endif
	for(i=0;i<sizeof(hI2C1);i++){
		if(i2cDeviceStatus & (1<<(i+2))) {
			SetBootVoltage(hI2C1[i], i);
		}
	}

#if 0	//TBD
	if(i2cDeviceStatus & (1<<6)){
		//GetMemAuxPwr();
		if(ReadEEpromDat(
				(uint8_t*)&value,
				EEPROM_BOOTVL_INDEX+(index*2),
				2
				) == HAL_OK) {
			voltage = swapbytes(value);
			if(voltage > 3600 || voltage < 3100) voltage = 3300;
			SetMemAuxPwr(voltage);
		}
	}
#endif
	SetBootVolDone = 1;
}

void CheckI2CDevcesStatus()
{
	uint8_t i;
	uint8_t hI2C1_Devices[] = {EEPROM_LAddr, EEPROM_HAddr, RAA_CD_Addr, RAA_EF_Addr, RAA_IJ_Addr, RAA_KL_Addr, ZL9006MIRZ_Addr};
	uint8_t hI2C2_Devices[] = {MAX6958_Addr, ADC121_CD_Addr, ADC121_EF_Addr, ADC121_IJ_Addr, ADC121_KL_Addr, ADC121_MT_Addr};

	for(i = 0 ; i < sizeof(hI2C1_Devices); i++) {
		if(HAL_I2C_IsDeviceReady(
				&hi2c1,
				(uint16_t)((hI2C1_Devices[i]) << 1),
				3,
				5
				)
			!= HAL_OK) {
			printf("i2c devices %x check not OK\n", hI2C1_Devices[i]);

		} else {
			printf("i2c devices %x check OK\n", hI2C1_Devices[i]);
			i2cDeviceStatus |= 1<<i;
		}
	}

	for(i=2;i<4;i++) {	//test
		if(i2cDeviceStatus & (1<<i)) {
			SetInputVolLimit(hI2C1_Devices[i]);
			SetDIMMCurrentLimit(hI2C1_Devices[i]);
			ConfigBootVoltage();
		}
	}
#if 1
	if(i2cDeviceStatus & (1<<6)){	//test
		GetMemAuxPwr();
	}
#endif
	for(i = 0 ; i < sizeof(hI2C2_Devices); i++) {
		if(HAL_I2C_IsDeviceReady(
				&hi2c2,
				(uint16_t)((hI2C2_Devices[i]) << 1),
				3,
				5
				)
			!= HAL_OK) {
			printf("i2c devices %x check not OK\n", hI2C2_Devices[i]);
		} else {
			printf("i2c devices %x check OK\n", hI2C2_Devices[i]);
			i2cDeviceStatus |= 1<< (i+sizeof(hI2C1_Devices));
		}
	}

	if(i2cDeviceStatus&(i<<7)) {	//test
		MAX6958AAEE_Init();
		MAX6958_DisplayDigit(0x20, 0x01); // Digit 0, Value 1
		MAX6958_DisplayDigit(0x21, 0x02); // Digit 1, Value 2
		MAX6958_DisplayDigit(0x22, 0x03); // Digit 2, Value 3
		MAX6958_DisplayDigit(0x23, 0x04); // Digit 3, Value 4
	}

	for(i=1;i<6;i++) {	//test
		uint16_t vol;
		if(i2cDeviceStatus & (1<<(7+i))){
			ReadCurVoltage(hI2C2_Devices[i], &vol);
		}
	}
}

void StartUartsReceive()
{
	//UART Function >>>>
	if(HAL_UARTEx_ReceiveToIdle_IT(
		  &huart1,
		  Uart1Buffer,
		  UART_BUFFER_SIZE
		  ) != HAL_OK) {
	  Error_Handler();
	}
/*
	if(HAL_UART_Receive_IT(
		  &huart2,
		  Uart1Buffer,
		  UART_BUFFER_SIZE
		  ) != HAL_OK) {
	  Error_Handler();
	}
*/
	if(HAL_UARTEx_ReceiveToIdle_IT(
		  &huart3,
		  Uart3Buffer,
		  UART_BUFFER_SIZE
		  ) != HAL_OK) {
	  Error_Handler();
	}

	if(HAL_UARTEx_ReceiveToIdle_IT(
		  &huart4,
		  Uart4Buffer,
		  UART4_BUFFER_SIZE
		  ) != HAL_OK) {
	  Error_Handler();
	}
}

void CheckBackMcuStatus()
{
	uint8_t Retry = 3;

	Uart3Buffer[0] = 0x02;
	Uart3Buffer[1] = 0x41;
	Uart3Buffer[2] = 0x00;
	Uart3Buffer[3] = 0x00;
	Uart3Buffer[4] = 0x00;
	Uart3Buffer[5] = 0x00;
	Uart3Buffer[6] = 0x00;
	Uart3Buffer[7] = 0x03;

	while (Retry != 0){

		HAL_GPIO_TogglePin(
				GPIOC,
			  	GPIO_PIN_0);	//LED9

		HAL_UART_Transmit(
				&huart3,
				(uint8_t*)&Uart3Buffer,
				UART_BUFFER_SIZE,
				HAL_MAX_DELAY);

		HAL_Delay(2000);
		Retry--;

		if(bBackMcuReady) {
			break;
		}
	}
}

void StartFans()
{
	//Fan Start >>>>
	HAL_GPIO_WritePin(
		  GPIOC,
		  GPIO_PIN_9,	//IRQ_PMBUS_PLD_ALERT_N
		  GPIO_PIN_RESET
  	  	  );

	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);

	//Duty Cycle
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 100);	//CPU FAN
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 100);	//SYS FAN
}

void ProcessFanRPM()
{
	if(HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_14) != 0) { ++CpuFan1Cnt; }

	if(HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_15) != 0) { ++CpuFan2Cnt; }

	if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_2) != 0) { ++SysFan1Cnt; }

	if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_3) != 0) { ++SysFan1Cnt; }
}

void RefreshFanPRM()
{
	FanTach1 = CpuFan1Cnt;
	FanTach2 = CpuFan2Cnt;
	FanTach3 = SysFan1Cnt;
	FanTach4 = SysFan2Cnt;

	CpuFan1Cnt = 0;
	CpuFan2Cnt = 0;
	SysFan1Cnt = 0;
	SysFan2Cnt = 0;
}

GPIO_PinState IsSLPS4_N()
{
	return HAL_GPIO_ReadPin(
			GPIOD,
			GPIO_PIN_9		//FM_SLPS4_CPU0_R_N
			);
}

GPIO_PinState IsPLTRST_N()
{
	return HAL_GPIO_ReadPin(
			GPIOE,
			GPIO_PIN_7		//RST_PLTRST_SYNC_CPU0_R_N
			);
}

void VRDD5_FWREN()
{
	while(!IsSLPS4_N()) {
		HAL_Delay(100);
		HAL_GPIO_TogglePin(
			GPIOC,
			GPIO_PIN_0);	//LED8
	}

	HAL_GPIO_WritePin(
		GPIOB,			//VR_DDR5_FWR_EN
		GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3,
		SET);

	StartFans();

	CheckI2CDevcesStatus();
	I2cDimmVolDone = 1;

	ConfigBootVoltage();

	HAL_GPIO_WritePin(
		GPIOC,
	 	GPIO_PIN_0,
	 	SET);
	//End of Earily MCU init light LED8
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_USART4_UART_Init();
  MX_TIM6_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  VRDD5_FWREN();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  StartUartsReceive();
  CheckBackMcuStatus();						//Start Check Back Plane devices

  HAL_TIM_Base_Start_IT(&htim6);			//Start Timer after all initial
  while(1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  HAL_Delay(100);

	  HAL_GPIO_TogglePin(
			GPIOC,
			GPIO_PIN_1);	//LED29

	  ProcessFanRPM();
	  //check system status

	  if(!IsSLPS4_N() && SetBootVolDone) {
		  SetBootVolDone = 0;
	  }

	  if(!SetBootVolDone) {
		  VRDD5_FWREN();
	  }

	  /*
	  if(IsPLTRST_N() && !I2cDimmVolDone) {
		  HAL_GPIO_WritePin(
				  GPIOB,
				  GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, //VR_DDR5_FWR_EN
				  SET);

		  CheckI2CDevcesStatus();
		  I2cDimmVolDone = 1;
	  }

	  if(!IsSLPS4_N() && !SetBootVolDone) {
		  //SLP S4 is Low
		  printf("Configure Boot Voltage\n");
		  VRDD5_FWREN();
		  SetBootVolDone = 1;
	  } else {

	  }
	  */
/*
		  ConfigBootVoltage();
		  HAL_GPIO_WritePin(
				  GPIOB,
				  GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, //VR_DDR5_FWR_EN
				  RESET);
		  I2cDimmVolDone = 0;

	  }
*/
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_USART2
                              |RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0000020B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x0000020B;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 8000-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 8000-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 100-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 8000-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 1000-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART4_UART_Init(void)
{

  /* USER CODE BEGIN USART4_Init 0 */

  /* USER CODE END USART4_Init 0 */

  /* USER CODE BEGIN USART4_Init 1 */

  /* USER CODE END USART4_Init 1 */
  huart4.Instance = USART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART4_Init 2 */

  /* USER CODE END USART4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_9, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7|GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET);

  /*Configure GPIO pin : PF10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 PC7 PC8
                           PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD8 PD9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : PA11 */
  GPIO_InitStruct.Pin = GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void SendCmd(uint8_t cmd)
{
	Uart3Buffer[0] = 0x02;
	Uart3Buffer[1] = 0x42;
	Uart3Buffer[2] = cmd & 0x0F;	//Low
	Uart3Buffer[3] = (cmd & 0xF0) >> 4;	//High

	HAL_UART_Transmit(&huart3, Uart3Buffer, UART_BUFFER_SIZE, HAL_MAX_DELAY);
}


void SendVol()
{
	Uart3Buffer[0] = 0x02;
	Uart3Buffer[1] = CMD_SET_OUT_VOLTAGE;

	HAL_UART_Transmit(&huart3, Uart3Buffer, UART_BUFFER_SIZE, HAL_MAX_DELAY);
}

void ShowVoltage(uint8_t i)
{
	uint16_t value=0;
	uint8_t Addr[]= {ADC121_CD_Addr, ADC121_EF_Addr, ADC121_IJ_Addr, ADC121_KL_Addr};

	if(ReadCurVoltage(Addr[i], &value) ==  HAL_OK) {
		Uart3Buffer[1] = i;
		Uart3Buffer[3] = (value / 10000) % 10;
		Uart3Buffer[4] = (value / 1000) % 10;
		Uart3Buffer[5] = (value / 100) % 10;
		SendVol();
	}
}

void TestBackMcuFun()
{
	Count++;

	SendCmd(Count);
	if((Count%4) < 4) ShowVoltage((Count%4));
	if(Count%9 == 0) GetMemAuxPwr();

}

void ProcessDimmCountDat()
{
	for(uint8_t i=0 ; i<MAX_DIMM_NUMBER ; i++) {
		switch(DimmCountAct[i]){	//0:NO Action, 1:Increment 2:Reset
			case 0:	//No Action

				break;

			case 1:	//Increment
				if(DimmStatus & (0x01 << i)) {
					DimmCountDat[i]++;
				}
				break;

			case 2:	//RESET
				DimmCountDat[i] = 0;
				break;
		}
	}
}

void ProcessHostCmd()
{
	uint8_t	Cmd;
	uint8_t Addr;
	uint16_t Voltage;

	Cmd = Uart1Buffer[CMD_INDEX];
	switch(Cmd) {
		case CMD_CHECK_CONNECTION: 					//Check Connection Command
			Uart1Buffer[CMD_INDEX] = CHECK_CONNECTION_DONE;
			break;

		case CMD_PORT80_DATA:						//PORT80 Data Send
			memcpy((uint8_t*)&Uart3Buffer, (uint8_t*)&Uart1Buffer, UART_BUFFER_SIZE);
			Uart3Transimt();	//send post command to back mcu

			break;

		case CMD_GET_FW_VERSION:					//Get Firmware Version
			if(Uart1Buffer[DAT0_INDEX] == 1) {		//Main MCU Version
				Uart1Buffer[DAT0_INDEX+1] = MCU_MAIN_VERSION;
				Uart1Buffer[DAT0_INDEX+2] = MCU_SUB_VERSION;
				Uart1Buffer[DAT0_INDEX+3] = MCU_NUM_VERSION;
			}

			if(Uart1Buffer[DAT0_INDEX] == 2) {		//Back MCU Version
				Uart1Buffer[DAT0_INDEX+1] = BMCURV[0];
				Uart1Buffer[DAT0_INDEX+2] = BMCURV[1];
				Uart1Buffer[DAT0_INDEX+3] = BMCURV[2];
			}
			Uart1Buffer[CMD_INDEX] = CHECK_FIRMWARE_DONE;

			break;

		case CMD_GET_CUR_VOLTAGE:		//Get Current Voltage

			if(Uart1Buffer[DAT0_INDEX] ==  1){
				Addr = ADC121_CD_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  2){
				Addr = ADC121_EF_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  3){
				Addr = ADC121_IJ_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  4){
				Addr = ADC121_KL_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] == 5){
				Addr = ADC121_MT_Addr;
			}

			//if(ReadCurVoltage(Addr, &Uart1Buffer[DAT0_INDEX]+1) == HAL_OK) {
			if(ReadCurVoltage(Addr, &Voltage) == HAL_OK) {
				Uart1Buffer[DAT0_INDEX+1] = (uint8_t)Voltage;
				Uart1Buffer[DAT0_INDEX+2] = (uint8_t)(Voltage >> 8);
				Uart1Buffer[CMD_INDEX] = CHECK_BOOTVLT_DONE;
			}

			break;

		case CMD_GET_MEM_COUNT:			//Get Memory Slot Count
			if(ReadEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_DIMM_COUNT_INDEX+(Uart1Buffer[DAT0_INDEX]-1)*sizeof(uint32_t),
					sizeof(uint32_t)
					) == HAL_OK) {
				Uart1Buffer[CMD_INDEX] = CHECK_MMCOUNT_DONE;
			}
			break;

		case CMD_GET_FAN_RPM:			//Get FAN RPM
			if(Uart1Buffer[DAT0_INDEX] == 1){	//CPU FAN 1
				memcpy(&Uart1Buffer[DAT0_INDEX+1], (uint8_t*)&FanTach1, 2);
			}

			if(Uart1Buffer[DAT0_INDEX] == 2){	//CPU FAN 2
				memcpy(&Uart1Buffer[DAT0_INDEX+1], (uint8_t*)&FanTach2, 2);
			}

			if(Uart1Buffer[DAT0_INDEX] == 3){	//SYS FAN 1
				memcpy(&Uart1Buffer[DAT0_INDEX+1], (uint8_t*)&FanTach3, 2);
			}

			if(Uart1Buffer[DAT0_INDEX] == 4) {	//SYS FAN 2
				memcpy(&Uart1Buffer[DAT0_INDEX+1], (uint8_t*)&FanTach4, 2);
			}

			Uart1Buffer[CMD_INDEX] = CHECK_FANRPM_DONE;
			break;

		case CMD_SET_OUT_VOLTAGE:		//Set Output Voltage

			if(Uart1Buffer[DAT0_INDEX] ==  1){
				Addr = RAA_CD_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  2){
				Addr = RAA_EF_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  3){
				Addr = RAA_IJ_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] ==  4){
				Addr = RAA_KL_Addr;
			}

			if(Uart1Buffer[DAT0_INDEX] == 5){
				Addr = ZL9006MIRZ_Addr;
				if(SetMemAuxPwr((uint8_t*)&Voltage) == HAL_OK) {
					Uart1Buffer[CMD_INDEX] = CONFIG_VOLTAGE_DONE;
				}
			} else {
				smemcpy((uint8_t*)&Voltage, &Uart1Buffer[DAT0_INDEX+1], 2);
				if(SetDimmVoltage(Addr, Voltage) == HAL_OK){
					Uart1Buffer[CMD_INDEX] = CONFIG_VOLTAGE_DONE;
				}
			}
			break;

		case CMD_GET_BOOT_VOLTAGE:		//Get Boot Voltage
			if(ReadEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_BOOTVL_INDEX+(Uart1Buffer[DAT0_INDEX]-1)*sizeof(uint16_t),
					sizeof(uint16_t)
					) == HAL_OK) {
					Uart1Buffer[CMD_INDEX] = CHECK_BOOTVLT_DONE;
			}
			break;

		case CMD_SET_BOOT_VOLTAGE:		//Set Boot Voltage
			if(WriteEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_BOOTVL_INDEX+(Uart1Buffer[DAT0_INDEX]-1)*sizeof(uint16_t),
					sizeof(uint16_t)
					) == HAL_OK) {
					SetBootVolDone = 0;		//New Boot Voltage
					Uart1Buffer[CMD_INDEX] = CONFIG_BOOTVLT_DONE;
			}
			break;

		case CMD_SET_LED:				//Set LED Status
			memcpy((uint8_t*)&Uart3Buffer, (uint8_t*)&Uart1Buffer, UART_BUFFER_SIZE);
			Uart3Transimt();	//directly send data to back mcu

			Uart1Buffer[CMD_INDEX] = CONFIG_LEDSTAT_DONE;

			break;

		case CMD_SET_MEM_COUNT_ACTION:
			if(Uart1Buffer[DAT0_INDEX] == 0) {
				memcpy((uint8_t*)&DimmCountAct[0],
					   (uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					   MAX_DIMM_NUMBER/2);
			}

			if(Uart1Buffer[DAT0_INDEX] == 1) {
				memcpy((uint8_t*)&DimmCountAct[MAX_DIMM_NUMBER/2],
					   (uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					   MAX_DIMM_NUMBER/2);
			}
			break;

		case CMD_SET_MEM_STATUS:
			DimmStatus = Uart1Buffer[DAT0_INDEX];
			ProcessDimmCountDat();

			Uart1Buffer[CMD_INDEX] = CHECK_MEMSTA_DONE;

			break;

		case CMD_SET_PWM_PULSE_WIDTH:

			if(Uart1Buffer[DAT0_INDEX] == 1 ||
			   Uart1Buffer[DAT0_INDEX] == 3) {
				//Duty Cycle
				__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, Uart1Buffer[DAT0_INDEX+1]*10);		//CPU FAN
			}

			if(Uart1Buffer[DAT0_INDEX] == 1 ||
			   Uart1Buffer[DAT0_INDEX] == 3) {
				__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, Uart1Buffer[DAT0_INDEX+1]*10);		//SYS FAN
			}

			Uart1Buffer[CMD_INDEX] = CONFIG_FANSPEED_DONE;
			break;

		case CMD_GET_IP_INFO: 			//Get IP Information
			if(ReadEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_IPINFO_INDEX+(Uart1Buffer[DAT0_INDEX]-1)*(IPINFO_DAT_NUMBER+1),
					(IPINFO_DAT_NUMBER+1)
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CHECK_IPINFO_DONE;
			}
			break;

		case CMD_SET_IP_INFO:
			if(WriteEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_IPINFO_INDEX+(Uart1Buffer[DAT0_INDEX]-1)*(IPINFO_DAT_NUMBER+1),
					(IPINFO_DAT_NUMBER+1)
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CONFIG_IPINFO_DONE;
			}
			break;

		case CMD_GET_BOARD_ID:			//REQ_GET_BOARDID

			if(ReadEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_BOARD_ID_INDEX+Uart1Buffer[DAT0_INDEX]*BOARDID_DAT_NUMBER,
					BOARDID_DAT_NUMBER
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CHECK_BOARDID_DONE;
			}
			break;

		case CMD_SET_BOARD_ID:			//REQ_SET_BOARDID

			if(WriteEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_BOARD_ID_INDEX+Uart1Buffer[DAT0_INDEX]*BOARDID_DAT_NUMBER,
					BOARDID_DAT_NUMBER
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CONFIG_BOARDID_DONE;
			}
			break;

		case CMD_GET_BOARD_SN:			//REQ_GET_SERIALNUMBER

			if(ReadEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_SERIAL_INDEX+Uart1Buffer[DAT0_INDEX]*SERIALID_DAT_NUMBER,
					SERIALID_DAT_NUMBER
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CHECK_SERIALNM_DONE;
			}
			break;

		case CMD_SET_BOARD_SN:			//REQ_SET_SERIALNUMBER

			if(WriteEEpromDat(
					(uint8_t*)&Uart1Buffer[DAT0_INDEX+1],
					EEPROM_SERIAL_INDEX+Uart1Buffer[DAT0_INDEX]*SERIALID_DAT_NUMBER,
					SERIALID_DAT_NUMBER
					) == HAL_OK) {

				Uart1Buffer[CMD_INDEX] = CONFIG_SERIALNM_DONE;
			}
			break;
/*//TBD >>>>
		case CMD_SET_SLEW_RATE:			//Set Slew Rate
	 			// TBD
	 		break;

		case CMD_GET_SLEW_RATE:			//Get Slew Rate
				//TBD
			break;

		case CMD_GET_USER_DAT:

			break;

		case CMD_SET_USER_DAT:

			break;

		case CMD_SET_VOLTAGE_TUNE:

			break;

		case CMD_SET_ADC_TUNE:

			break;

		case CMD_BEEP_TEST:

			break;
*/ //TBD <<<<
	}

	if(Cmd != Uart1Buffer[CMD_INDEX]) {
		Uart1Transimt();
	}
}

void ProcessM2MCmd()
{
	uint8_t Cmd = *(Uart3Buffer+CMD_INDEX);
	switch(Cmd){
		case CHECK_CONNECTION_DONE: 	//Back Plane is Ready
			BMCURV[0] = Uart3Buffer[DAT0_INDEX];
			BMCURV[1] = Uart3Buffer[DAT0_INDEX+1];
			BMCURV[2] = Uart3Buffer[DAT0_INDEX+2];
			bBackMcuReady = 1;
		break;
	}
}

void ProcessCbxCmd()
{
	uint8_t GETRP[5] = {'G','E','T','R','P'};		//CBX GETRPM
	uint8_t GETID[5] = {'G','E','T','I','D'};		//CBX GETID
	uint8_t GETSC[5] = {'G','E','T','S','C'};		//CBX GETSC
	uint8_t GETIP[5] = {'G','E','T','I','P'};		//CBX GETIP
	uint8_t SETIP[5] = {'S','E','T','I','P'};		//CBX SETIP

	if(!memcmp((uint8_t*)&Uart4Buffer[0], GETRP, 5)) {	//Cbx Get RPM
		Uart4Buffer[0] = 'R'; Uart4Buffer[1] = 'P'; Uart4Buffer[2] = 'M';
		Uart4Buffer[3] = 0x00; Uart4Buffer[4] = 0x04; Uart4Buffer[5] = 0x00;

		smemcpy(&Uart4Buffer[6], (uint8_t*)&FanTach1, 2);
		smemcpy(&Uart4Buffer[9], (uint8_t*)&FanTach2, 2);
		smemcpy(&Uart4Buffer[12], (uint8_t*)&FanTach3, 2);
		smemcpy(&Uart4Buffer[15], (uint8_t*)&FanTach4, 2);

		Uart4Transimt((uint8_t*)&Uart4Buffer[0], 17);
	}

	if(!memcmp((uint8_t*)&Uart4Buffer[0], GETID, 5)) {	//Cbx Get ID
		Uart4Buffer[0] = 'I'; Uart4Buffer[1] = 'D'; Uart4Buffer[2] = 0x00;

		for(uint8_t i=0 ; i<BOARDID_DAT_NUMBER ;i++) {
				if(ReadEEpromDat(
						(uint8_t*)&Uart4Buffer[3+(i*4)],
						EEPROM_BOARD_ID_INDEX+i*BOARDID_DAT_NUMBER,
						BOARDID_DAT_NUMBER
					) != HAL_OK) {
			}
		}
		Uart4Transimt((uint8_t*)&Uart4Buffer[0], 19);
	}

	if(!memcmp((uint8_t*)&Uart4Buffer[0], GETSC, 5)) {	//Cbx Get SC
		uint8_t tmpBuf[40]={0};
		tmpBuf[0] = 'S'; tmpBuf[1] = 'C'; tmpBuf[3] = '0'; tmpBuf[4] = '8';

		for(uint8_t i=0 ; i<MAX_DIMM_NUMBER ; i++) {
			if(ReadEEpromDat(
				(uint8_t*)&tmpBuf[6+(i*4)],
				EEPROM_DIMM_COUNT_INDEX+i*4,
				4) != HAL_OK) {
			}
		}
		Uart4Transimt((uint8_t*)&Uart4Buffer[0], 40);
	}

	if(!memcmp((uint8_t*)&Uart4Buffer[0], GETIP, 5)) {	//Cbx Get IP
		if(ReadEEpromDat(
			(uint8_t*)&Uart4Buffer[0],
			EEPROM_IPINFO_INDEX,
			(IPINFO_DAT_NUMBER+1)
				) != HAL_OK) {
		}

		Uart4Transimt((uint8_t*)&Uart4Buffer[0], (IPINFO_DAT_NUMBER+1));
	}

	if(!memcmp((uint8_t*)&Uart4Buffer[0], SETIP, 5)) {	//Cbx SET IP
		if(WriteEEpromDat(
				(uint8_t*)&Uart4Buffer[6],
				EEPROM_IPINFO_INDEX,
				4
				) != HAL_OK) {
		}
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_10) {	//MCU SW4
		// TBD SW4 pressed
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM6) {	//1 sec

		if(bBackMcuReady) {
			TestBackMcuFun();	//Test
		}

		RefreshFanPRM();
	}
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
  UNUSED(Size);

  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_UARTEx_RxEventCallback can be implemented in the user file.
   */

  if(huart->Instance == USART1) {	//From Host
	  printf("BMC Uart\n");
	  strOut2(Uart1Buffer, UART_BUFFER_SIZE);
	  ProcessHostCmd();
	  if(HAL_UARTEx_ReceiveToIdle_IT(
			  &huart1,
			  Uart1Buffer,
			  UART_BUFFER_SIZE
			  ) != HAL_OK) {
		  Error_Handler();
	  }
  }

  if(huart->Instance == USART3) {	//Back MCU
	  ProcessM2MCmd();
	  if(HAL_UARTEx_ReceiveToIdle_IT(
			  &huart3,
			  Uart3Buffer,
			  UART_BUFFER_SIZE
			  ) != HAL_OK) {
		  Error_Handler();
	  }
  }

  if(huart->Instance == USART4) {	//CBX
	  printf("CBX Uart\n");
	  strOut2(Uart4Buffer, UART4_BUFFER_SIZE);
	  HAL_UART_Transmit(
			  &huart2,
			  (uint8_t*)&Uart4Buffer,
			  Size,
			  0xFFFF);
	  ProcessCbxCmd();
	  if(HAL_UARTEx_ReceiveToIdle_IT(
			  &huart4,
			  Uart4Buffer,
			  UART4_BUFFER_SIZE
			  ) != HAL_OK) {
		  Error_Handler();
	  }
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
