/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */
#define MCU_MAIN_VERSION			0
#define MCU_SUB_VERSION				0
#define MCU_NUM_VERSION				1

#define ZL9006MIRZ_Addr				0x61	//I2C1 (MCU_SCL)
#define RAA_CD_Addr					0x48	//0x90	//ADDR 0 | 0	I2C1 (MCU_SCL)
#define RAA_EF_Addr					0x49	//0x92	//ADDR 0 | 1	I2C1 (MCU_SCL)
#define RAA_IJ_Addr					0x4A	//0x94	//ADDR 1 | 0	I2C1 (MCU_SCL)
#define RAA_KL_Addr					0x4B	//0x96	//ADDR 1 | 1	I2C1 (MCU_SCL)
#define EEPROM_LAddr				0x56 	//A8_BIT = 0
#define EEPROM_HAddr 				0x57 	//A8_BIT = 1

#define MAX6958_Addr				0x38	//I2C2 (ADC_I2C_SCL)
#define ADC121_CD_Addr 				0x56	//I2C2 (ADC_I2C_SCL)
#define ADC121_EF_Addr 				0x58	//I2C2 (ADC_I2C_SCL)
#define ADC121_IJ_Addr 				0x59	//I2C2 (ADC_I2C_SCL)
#define ADC121_KL_Addr 				0x5A	//I2C2 (ADC_I2C_SCL)
#define ADC121_MT_Addr				0x55	//I2C2 (ADC_I2C_SCL)

#define MAX_DIMM_NUMBER 			8

#define CMD_INDEX					1
#define DAT0_INDEX					2

#define CMD_CHECK_CONNECTION		0x41	//Check Connection Command
#define CMD_PORT80_DATA				0x42	//PORT80 Data Send
#define CMD_GET_FW_VERSION			0x51	//Get Firmware Version
#define CMD_GET_CUR_VOLTAGE			0x52	//Get Current Voltage
#define CMD_GET_SLEW_RATE			0x53	//Get Slew Rate
#define CMD_GET_BOOT_VOLTAGE		0x54	//Get Boot Voltage
#define CMD_GET_MEM_COUNT			0x55	//Get Memory Count Value
#define CMD_GET_FAN_RPM				0x56	//Get FAN RPM
#define CMD_SET_MEM_STATUS			0x57	//Set Memory Status
#define CMD_SET_OUT_VOLTAGE			0x61	//Set Output Voltage
#define CMD_SET_SLEW_RATE			0x62	//Set Slew Rate
#define CMD_SET_BOOT_VOLTAGE		0x63	//Set Boot Voltage
#define CMD_SET_LED					0x64	//Set LED Status
#define CMD_SET_MEM_COUNT_ACTION	0x65	//Set Memory Count Action
#define CMD_SET_VOLTAGE_TUNE		0x66	//Set Voltage Tune function
#define CMD_SET_ADC_TUNE			0x67	//Set ADC Tune function
#define CMD_SET_PWM_PULSE_WIDTH		0x68	//Set FAN SPEED
#define CMD_BEEP_TEST				0x69	//Beep Function Test

#define CMD_GET_IP_INFO				0x71	//Get IP Information
#define CMD_SET_IP_INFO				0x78	//Set IP Informations

#define CMD_GET_BOARD_ID			0x72	//Get ID
#define CMD_SET_BOARD_ID			0x73	//Set ID
#define CMD_GET_BOARD_SN			0x74	//Get SN
#define CMD_SET_BOARD_SN			0x75	//Set SN

#define CMD_GET_USER_DAT			0x76	//Get User Data
#define CMD_SET_USER_DAT			0X77	//Set User Data

#define CHECK_CONNECTION_DONE		0x81
#define CHECK_FIRMWARE_DONE			0x91
#define CHECK_VOLTAGE_DONE			0x92
#define CHECK_SLEWRATE_DONE			0x93
#define CHECK_BOOTVLT_DONE			0x94
#define CHECK_MMCOUNT_DONE			0x95
#define CHECK_FANRPM_DONE			0x96
#define CHECK_MEMSTA_DONE			0x97

#define CONFIG_VOLTAGE_DONE			0xA1
#define CONFIG_SLEWRAT_DONE			0xA2
#define CONFIG_BOOTVLT_DONE			0xA3
#define CONFIG_LEDSTAT_DONE			0xA4

#define CONFIG_FANSPEED_DONE		0xA8

#define CHECK_IPINFO_DONE			0xB1
#define	CHECK_BOARDID_DONE			0xB2
#define CONFIG_BOARDID_DONE			0xB3
#define	CHECK_SERIALNM_DONE			0xB4
#define CONFIG_SERIALNM_DONE		0xB5

#define CHECK_USERDAT_DONE			0xB6
#define CONFIG_USERDAT_DONE			0xB7

#define CONFIG_IPINFO_DONE			0xB8

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
