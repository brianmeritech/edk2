/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX_UART_PACKAGE_SIZE		8
#define MAX_POST_CODE_LED_NUMBER 	2
#define MAX_VDD_LED_NUMBER 			12
#define MAX_PASS_FAIL_LED_NUMBER	8

#define CHECK_CONNECTION_DONE		0x81


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static uint8_t DigAB = 0;
static uint8_t DigCD = 3;
static uint8_t DigEF = 6;
static uint8_t DigGH = 9;

static uint8_t DgIndex = 6;
static uint8_t bHostReady = 0;

static const uint8_t SEVEN_LED[16] = {
		0x3F, //Display '0'
		0x06, //Display '1'
		0x5B, //Display '2'
		0x4F, //Display '3'
		0x66, //Display '4'
		0x6D, //Display '5'
		0x7D, //Display '6'
		0x07, //Display '7'
		0x7F, //Display '8'
		0x6F, //Display '9'
		0x77, //Display 'A'
		0x7C, //Display 'b'
		0x39, //Display 'c'
		0x5E, //Display 'd'
		0x79, //Display 'E'
		0x71  //Display 'F'
};

static uint8_t UartBuf[MAX_UART_PACKAGE_SIZE]={0};
static uint8_t* gUartBuf = &UartBuf[0];

// Common memory for led access
static uint8_t PostCodeDat[MAX_POST_CODE_LED_NUMBER]={0};	//HIGH LOW
static uint8_t P12VVDDLedDat[MAX_VDD_LED_NUMBER]={0};
static uint8_t PassFailLedDat[MAX_PASS_FAIL_LED_NUMBER]={0};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*
static void strOut1(uint8_t* pStr, uint16_t s)//M2M
{
	HAL_UART_Transmit(&huart1, pStr, s, 0xFFFF);
}

static void strOut2(uint8_t* pStr, uint16_t s)
{
	HAL_UART_Transmit(&huart2, pStr, s, 0xFFFF);
}
*/
static void StartPassLed(uint8_t Pin)
{
	 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4, SET);
	 HAL_GPIO_WritePin(GPIOB, 1<<(Pin+8), SET);
	 HAL_Delay(1);
	 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4, RESET);
	 HAL_GPIO_WritePin(GPIOB, 1<<(Pin+8), RESET);
}

static void StartFailLed(uint8_t Pin)
{
	 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_5, SET);
	 HAL_GPIO_WritePin(GPIOB, 1<<(Pin+8), SET);
	 HAL_Delay(1);
	 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_5, RESET);
	 HAL_GPIO_WritePin(GPIOB, 1<<(Pin+8), RESET);
}

static void StartPassFailLed()
{
	for(uint8_t pfIndex = 0; pfIndex < 8 ; pfIndex++){
		switch(PassFailLedDat[pfIndex]){
		case 0:	//Blank
				continue;
			break;
		case 1:	// Pass
			StartPassLed(pfIndex);
			break;
		case 2:	// Fail
			StartFailLed(pfIndex);
			break;
		}
	}
}

static void StartPostLed()
{
	 HAL_GPIO_WritePin(GPIOF, (1<<DgIndex), SET);
	 HAL_GPIO_WritePin(GPIOB, SEVEN_LED[PostCodeDat[DgIndex-6]], SET);
	 HAL_Delay(1);
	 HAL_GPIO_WritePin(GPIOF, (1<<DgIndex), RESET);
	 HAL_GPIO_WritePin(GPIOB, SEVEN_LED[PostCodeDat[DgIndex-6]], RESET);
	 DgIndex++;
	 //if(DigIndex > MAX_DIG_NUMBER) DigIndex = 0;
	 if(DgIndex > 7) DgIndex = 6;
}

static void StartP12VABLed()
{
	HAL_GPIO_WritePin(GPIOC, (1<<DigAB), SET);
	if(DigAB == 1) {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigAB]]|GPIO_PIN_7, SET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigAB]], SET);
	}
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOC, (1<<DigAB), RESET);
	if(DigAB == 1) {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigAB]]|GPIO_PIN_7, RESET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigAB]], RESET);
	}
	DigAB++;
	if(DigAB > 2) DigAB = 0;
}

static void StartP12VCDLed()
{
	HAL_GPIO_WritePin(GPIOC, (1<<DigCD), SET);
	if(DigCD == 4) {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigCD]]|GPIO_PIN_7, SET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigCD]], SET);
	}
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOC, (1<<DigCD), RESET);
	if(DigCD == 4) {
			HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigCD]]|GPIO_PIN_7, RESET);
	}else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigCD]], RESET);
	}
	DigCD++;
	if(DigCD > 5) DigCD = 3;
}

static void StartP12VEFLed()
{
	HAL_GPIO_WritePin(GPIOC, (1<<DigEF), SET);
	if(DigEF == 7) {
		HAL_GPIO_WritePin(GPIOB, (SEVEN_LED[P12VVDDLedDat[DigEF]]|GPIO_PIN_7) << 8, SET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigEF]] << 8, SET);
	}
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOC, (1<<DigEF), RESET);
	if(DigEF == 7) {
		HAL_GPIO_WritePin(GPIOB, (SEVEN_LED[P12VVDDLedDat[DigEF]]|GPIO_PIN_7) << 8, RESET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigEF]] << 8, RESET);
	}
	DigEF++;
	if(DigEF > 8) DigEF = 6;
}

static void StartP12VGHLed()
{
	HAL_GPIO_WritePin(GPIOC, (1<<DigGH), SET);
	if(DigGH == 10) {
		HAL_GPIO_WritePin(GPIOB, (SEVEN_LED[P12VVDDLedDat[DigGH]]|GPIO_PIN_7) << 8, SET);
	} else {
		HAL_GPIO_WritePin(GPIOB, SEVEN_LED[P12VVDDLedDat[DigGH]] << 8, SET);
	}
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOC, (1<<DigGH), RESET);
	if(DigGH == 10) {
			HAL_GPIO_WritePin(GPIOB, (SEVEN_LED[P12VVDDLedDat[DigGH]]|GPIO_PIN_7) << 8, RESET);
	} else {
		HAL_GPIO_WritePin(GPIOB, (SEVEN_LED[P12VVDDLedDat[DigGH]]|GPIO_PIN_7) << 8, RESET);
	}
	DigGH++;
	if(DigGH > 11) DigGH = 9;
}

void WaitHostStatus()
{

	// Initial LED status >>>>
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_6|GPIO_PIN_7, SET);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
	                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
	                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
	                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11, SET);


	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_6|GPIO_PIN_7,
						GPIO_PIN_SET);
	// Initial LED status <<<<

	while(!bHostReady) {
		HAL_Delay(500);
		HAL_GPIO_TogglePin(
				GPIOC,
		  		GPIO_PIN_13);	//LED3
	}

	// Clear Initial LED Status >>>>
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_6|GPIO_PIN_7, RESET);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
		                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
		                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
		                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11, RESET);


	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_6|GPIO_PIN_7,
							GPIO_PIN_RESET);
	// Clear Initial LED Status <<<<

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  //Enable Uart receive function
  if(HAL_UARTEx_ReceiveToIdle_IT(
		  &huart1,
		  UartBuf,
		  MAX_UART_PACKAGE_SIZE
		  ) != HAL_OK) {
	  Error_Handler();
  }
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, SET);

  WaitHostStatus();	//Wait for Main Ready and Uart interface works normally
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  //HAL_TIM_Base_Start_IT(&htim6)
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, RESET);
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, RESET);

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  StartPassFailLed();
	  StartPostLed();
	  StartP12VABLed();
	  StartP12VCDLed();
	  StartP12VEFLed();
	  StartP12VGHLed();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 PC0
                           PC1 PC2 PC3 PC4
                           PC5 PC6 PC7 PC8
                           PC9 PC10 PC11 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PF4 PF5 PF6 PF7 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB10
                           PB11 PB12 PB13 PB14
                           PB15 PB3 PB4 PB5
                           PB6 PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM6) {
		  HAL_GPIO_TogglePin(
		  		  GPIOC,
		  		  GPIO_PIN_13);	//LED3
	}
}
*/

void ProcessReadyStatus()
{
	uint8_t bStatus = 1;
	uint8_t checkdat[MAX_UART_PACKAGE_SIZE]={
			0x02, 0x41,
			0x00, 0x00, 0x00, 0x00, 0x00,
			0x03
	};

	for(uint8_t i=0 ; i < MAX_UART_PACKAGE_SIZE ; i++ ){
		if(checkdat[i] != gUartBuf[i]) {
			bStatus = 0;
		}
	}

	if(bStatus){
		bHostReady = 1;
		gUartBuf[DAT0_INDEX] = MCU_MAIN_VERSION;
		gUartBuf[DAT0_INDEX+1] = MCU_SUB_VERSION;
		gUartBuf[DAT0_INDEX+2] = MCU_NUM_VERSION;
		gUartBuf[CMD_INDEX] = CHECK_CONNECTION_DONE;

		HAL_UART_Transmit(
				&huart1,
				gUartBuf,
				MAX_UART_PACKAGE_SIZE,
				HAL_MAX_DELAY);
	}
}

void ProcessLedStatusData()
{
	uint8_t	Shift =0;

	switch(*(gUartBuf+DAT0_INDEX)){
	case 0:	// LED 1 ~ 4
		Shift = 0;
		break;
	case 1:	// LED 5 ~ 8
		Shift = 4;
		break;
	}

	for(uint8_t i=0 ; i<4 ;i++){
		PassFailLedDat[i+Shift] = *(gUartBuf+3+i);
	}
}

void ProcessPostCodeData()
{
#if 0
	PostCodeDat[0] = *(gUartBuf+3);	//High
	PostCodeDat[1] = *(gUartBuf+2); //Low
#else
	PostCodeDat[0] = (*(gUartBuf+2)&0xF0) >> 8;	//High
	PostCodeDat[1] = *(gUartBuf+2)&0x0F; 		//Low

#endif
}

void ProcessVoltageData()
{
	uint8_t Shift = 0;

	switch(*(gUartBuf+DAT0_INDEX)){
	case 1: //channel AB
		Shift = 0;
		break;
	case 2: //channel CD
		Shift = 3;
		break;
	case 3: //channel EF
		Shift = 6;
		break;
	case 4: //channel GH
		Shift = 9;
		break;
	}

	for(uint8_t i=0 ; i<3 ;i++){
		P12VVDDLedDat[i+Shift] = *(gUartBuf+3+i);
	}
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
  UNUSED(Size);

  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_UARTEx_RxEventCallback can be implemented in the user file.
   */
  if(huart->Instance == USART1) {

	  if(Size == 8){
		  switch(*(gUartBuf+CMD_INDEX)){
		  	  case CMD_CHECK_CONNECTION: 	//Check Back MCU
		  		  ProcessReadyStatus();

		      case CMD_PORT80_DATA: 	//set post code data
	  	  		  ProcessPostCodeData();
		  	  break;

		  	  case CMD_SET_OUT_VOLTAGE: 	//set output voltage
			  	  ProcessVoltageData();
			  break;

		  	  case CMD_SET_LED: 	//set led status
			  	  ProcessLedStatusData();
		  	  break;
	  	  }
	  }

	  if(HAL_UARTEx_ReceiveToIdle_IT(
			  &huart1,
			  UartBuf,
			  MAX_UART_PACKAGE_SIZE
			  ) != HAL_OK) {
		  Error_Handler();
	  }
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
